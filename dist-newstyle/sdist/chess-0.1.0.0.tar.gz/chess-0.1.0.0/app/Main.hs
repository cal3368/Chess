module Main (main) where

import qualified Chess

main :: IO ()
main = Chess.main
